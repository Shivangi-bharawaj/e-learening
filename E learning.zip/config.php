<?php
$host="localhost";
$username="root";
$pass="";
$dbname="course";
$conn=mysqli_connect($host,$username,$pass,$dbname);
?>